namespace HttpServer.Configuration;

public class ConnectionStrings
{
    public string ServerConnectionString { get; set; }
    
    public string AuthConnectionString { get; set; }
}