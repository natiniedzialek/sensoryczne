namespace HttpServer.Configuration;

public class JwtOptions
{
    public string EncryptionKey { get; set; }
}